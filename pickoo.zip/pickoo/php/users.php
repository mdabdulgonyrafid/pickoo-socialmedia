<?php include('config.php');
session_start();
$sx=$_SESSION['unique_id'];
$x=mysqli_query($conn,"SELECT * FROM c_f_r WHERE frnd_uid='$sx'");
?>
<?php
while($z=mysqli_fetch_array($x)){
?>
<?php

$xn=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$z['my_uid']}'"));
$xnz=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$z['my_uid']}'"));
?>
<table>
<tr>
<td>
  <img src="php/images/<?php echo $xn['img']; ?>" style="object-fit: cover;border-radius: 50%;height: 45px;width: 45px;margin: 0 15px" alt="<?php echo $xnz['fname'];?> <?php echo $xnz['lname'];?>">
</td>
<td>
<span style="padding-top: 0px;"><a href="chat.php?user_id=<?php echo $z['my_uid'];?>" style="margin-top:35px;color:black;"><b><?php echo $xnz['fname'];?> <?php echo $xnz['lname'];?></b></a><br></span>
</td>
</tr>
</table>
<?php }?>
<?php $xb=mysqli_query($conn,"SELECT * FROM c_f_r WHERE my_uid='$sx'");
?>
<?php while($zb=mysqli_fetch_array($xb)){
?>
<?php $xnb=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$z['frnd_uid']}'"));
$xnzb=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$zb['frnd_uid']}'"));
?>
<table>
<tr>
<td>
  <img src="php/images/<?php echo $xnzb['img']; ?>" style="object-fit: cover;border-radius: 50%;height: 45px;width: 45px;margin: 0 15px" alt="<?php echo $xnzb['fname'];?> <?php echo $xnzb['lname'];?>">
</td>
<td>
<span style="padding-top: 0px;"><a href="chat.php?user_id=<?php echo $zb['frnd_uid'];?>" style="margin-top:35px;color:black;"><b><?php echo $xnzb['fname'];?> <?php echo $xnzb['lname'];?></b></a><br></span>
</td>
</tr>
</table>
<?php }?>