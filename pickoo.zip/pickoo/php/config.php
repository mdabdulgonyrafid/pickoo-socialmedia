<?php
  $hostname = "fdb28.awardspace.net";
  $username = "3693356_memes";
  $password = "rafid2460";
  $dbname = "3693356_memes";

  $conn = mysqli_connect($hostname, $username, $password, $dbname);
  if(!$conn){
    echo "Database connection error".mysqli_connect_error();
  }
?>
