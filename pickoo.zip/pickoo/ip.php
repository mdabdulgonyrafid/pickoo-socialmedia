<?php

$aa=$_SERVER['REMOTE_ADDR'];
 $user_agent = $_SERVER["HTTP_USER_AGENT"];
    $os = array("iPhone", "iPad", "iPod", "Android");
    
    foreach($os as $str)
    {
       
    if(strpos($user_agent, $str) !== false)
        
{         echo '<body style="font-family : arial;font-size: 20px;">';
              echo $str;
              echo  $user_agent;
 echo '<br>';
echo $aa;
         echo '</body>';
        }
    }

$dev=array("TECNO","OPPO");
foreach($dev as $st)
    {
       
    if(strpos($user_agent, $st) !== false)
        
{         echo '<body style="font-family : arial;font-size: 20px;">';
echo '<br>';
              echo $st;
              echo  $user_agent;
         echo '</body>';
        }
    }
 
?>
