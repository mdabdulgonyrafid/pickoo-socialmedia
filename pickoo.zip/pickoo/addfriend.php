<?php
include('db.php');
session_start();
$a="";
$ca="";
if(isset($_POST['cap'])){
$ca=$_POST['cap'];
}
if(isset($_SESSION['uid'])){

$a=$_SESSION['uid'];
}
if($a){
 

}else{
 header('location:index.php?ref_page=profile.php&view=mobile');
}
$sql=mysqli_query($con,"SELECT * FROM signup WHERE uid!='$a'");
?>
<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content='width=device-width, initial-scale=1'>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik&display=swap" rel="stylesheet">
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Glory&display=swap" rel="stylesheet">
				<link rel='preconnect' href='https://fonts.googleapis.com'>
				<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
				<link href='https://fonts.googleapis.com/css2?family=Montserrat&display=swap' rel='stylesheet'>
				<link rel='stylesheet' href='assets/demo.css'>
				<link rel='stylesheet' href='s.css'>
				<link rel='stylesheet' href='assets/header-fixed.css'>
			<link href = 'https://fonts.googleapis.com/icon?family=Material+Icons' rel = 'stylesheet'>
				<link href='https://fonts.googleapis.com/css?family=Cookie' rel='stylesheet' type='text/css'>
			<link rel='preconnect' href='https://fonts.googleapis.com'>
<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
<link href='https://fonts.googleapis.com/css2?family=Yanone+Kaffeesatz:wght@700&display=swap' rel='stylesheet'>
       <link rel='preconnect' href='https://fonts.googleapis.com'>
<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
<link href='https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap' rel='stylesheet'>
<script src='https://code.jquery.com/jquery-2.1.3.min.js'></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<title> Home | Ruby </title>
<style>
body {margin:0;}

.navbar {
  overflow: hidden;
  background-color: #E0115F;
  position: fixed;
  top:0;
  width: 100%;
}


.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 1px 1px;
  text-decoration: none;
  font-size: 1px;
}

/*.navbar a:hover{
  background: #ddd;
  
}*/

.main {
  padding: 16px;
  margin-top: 50px;
  height: 1500px; /* Used in this example to enable scrolling */
}
.material-icons{
color: white;
font-size: 35px;
}
.h_logo{
height:30px;
width:30px;
}
.sbt{
border:none;
outline:none;
background:#E0115F;
color:white;
border-radius:5px;
padding:3px;
font-size:18px;
}
.filelabel .title {
  color: #0693cd;;
}
#FileInput{
    display:none;
}
a{
text-decoration: none;
color: black;
}
</style>
</head>
<body>
<div class="navbar">
  <a href="#home"><span style="color: cyan;" class="material-icons">
article
</span></a>
  <a href="friends.php">
<span class="material-icons">
people
</span></a>
  <a href="#contact"><span class="material-icons">
email
</span></a>
  <a href="#contact"><span class="material-icons">
notifications
</span></a>
  <a href="#contact"><span class="material-icons">
search
</span></a>
 <a href="profile.php?ref_page=home.php&view=mobile"><span class="material-icons"><span class="material-icons">
account_circle
</span></a>
 <a href="#contact"><span class="material-icons">
menu
</span></a>
</div>

<div class="main">
<div>
<a href="friends.php"><span style="font-size:22px;padding:5px;border-radius:15px;background:rgba(113,121,126,.2);border:2px solid rgba(113,56,83,.6);">Requests</span></a><span style="font-size:22px;padding:5px;border-radius:15px;background:rgba(113,121,126,.2);float:right;">Add Friend</span>
</div>
<br>
<?php while($f=mysqli_fetch_array($sql)){?>
<div class="req">

<table>
<tr>
<td><img src="web_img_material/pro/<?php echo $f['profile_img'];?>" style="border-radius:50%;height:80px;width:80px;"/></td>
<td>
<span style="font-family:arial;font-weight:bold;padding-bottom:10px;font-family: 'Rubik', sans-serif;">&nbsp;<?php echo $f['fname'];?>&nbsp;<?php echo $f['lname'];?></span><span style="color:rgba(0,0,255,.4);font-size:16px;" class="material-icons">
verified
</span><span style="float:right;color:rgba(0,0,0,.7);font-size:15px;">&nbsp;30days</span><br><span style="color:rgba(0,0,0,.6);">&nbsp;@<?php echo $f['username'];?></span><br>
<input type="submit" style="background:#3b5998;outline:none;border:none;color:white;padding:3px;font-family: 'Glory', sans-serif;border-radius:5px;font-size:17px;font-weight:bold;" value="Confrim Request"/>&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" style="background:rgba(161, 230, 220,.8);outline:none;border:none;color:black;padding:5px;font-family: 'Glory', sans-serif;border-radius:5px;font-size:17px;font-weight:bold;" value="Delete Request"/>
</td>
</tr>
</table>
<hr>
</div>
<?php }?>
</div>
</body>
</html>