<?php
include('php/config.php');
session_start();
$u=$_SESSION['unique_id'];
$fu=$_GET['fid'];
mysqli_query($conn,"DELETE FROM c_f_r WHERE frnd_uid='$u' AND my_uid='$fu'");
header('location:myfrnd.php');
?>
