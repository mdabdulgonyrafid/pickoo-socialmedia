<?php
include('php/config.php');
session_start();
$d=$_SESSION['unique_id'];
$xp=$_GET['fuid'];
if(!isset($_SESSION['unique_id'])){
header('location: login.php');
}
mysqli_query($conn,"INSERT INTO c_f_r VALUES('','$d','$xp')");
mysqli_query($conn,"DELETE FROM friend_request WHERE my_uid='$xp' AND frnd_uid='$d'");
header('location: getrequest.php');
?>
