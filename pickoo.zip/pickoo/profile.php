<?php
include('php/config.php');
session_start();
if(!isset($_SESSION['unique_id'])){
header('location: user.php');
}
$mail=$_SESSION['unique_id'];
$cbz=mysqli_query($conn,"SELECT * FROM users where unique_id='$mail'");
$dbz=mysqli_fetch_array($cbz);
$vvbz=$dbz['img'];
?>
<doctype!>
<html>
<head>
<title> | Profile</title>
<style>
.profile{

}
.devo{
display:hidden;

}

#nii{
   overflow-x: hidden;
   width: 200px;
   height: 200px;
   border: 1px solid black;
}
</style>
</head>
<body>
<?php if (isset($_GET['error'])): ?>
		<p><?php echo $_GET['error']; ?></p>
	<?php endif ?>
<h2> Home Page Banner Change</h2>
<div class="profile">
<a href="uploads/<?php echo $vvbz?>">
<img src="php/images/<?php echo $vvbz?>" id="nii">
</a>
</div>

     <form action="upload.php"
           method="post"
           enctype="multipart/form-data">
           <input type="file"
                  name="my_image" class="devo" accept="image/*">
           <input type="submit" 
                  name="submit"
                  value="Upload">
     
 
<br>
    </form>
</body>
</html>
