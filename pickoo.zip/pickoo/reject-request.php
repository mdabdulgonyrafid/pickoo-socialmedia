<?php
include('php/config.php');
session_start();
$u=$_SESSION['unique_id'];
$fu=$_GET['fid'];
$sql=mysqli_query($conn,"SELECT * FROM friend_request where my_uid='$u' AND frnd_uid='$fu'");
mysqli_query($conn,"DELETE FROM friend_request WHERE my_uid='$fu' AND frnd_uid='$u'");
header('location:getrequest.php');
?>
