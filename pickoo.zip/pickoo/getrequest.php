<?php
include('php/config.php');
session_start();
if(!isset($_SESSION['unique_id'])){
header('location: login.php');
}else{

$sql=mysqli_query($conn,"SELECT * FROM friend_request WHERE frnd_uid='{$_SESSION['unique_id']}'");
}
?>
<head>
 <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Realtime Chat App | CodingNepal</title>
<style>
#a1{
text-decoration: none;
font-family: arial;
background:#234245;
color:white;
padding: 02px 03px 02px 03px;
border-radius: 5px;
}
#a2{
text-decoration: none;
font-family: arial;
background:grey;
color:white;
padding: 02px 03px 02px 03px;
border-radius: 5px;
}
</style>
</head>
<body style="font-family:arial">
<h2>Sent Request</h2>
<?php
while($g=mysqli_fetch_array($sql)){
?>
<?php
$sql3=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$g['my_uid']}'"));

?>
<div style="none">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="php/images/<?php echo $sql3['img'];?>" style="object-fit: cover;border-radius: 50%;height: 85px;width: 85px;margin: 0 15px"/>
</div><br>
<span style="font-family:arial;font-weight:bold;font-size: 20px;margin-left: 20px;"><?php echo $sql3['fname'];?> <?php echo $sql3['lname'];?></span>
<br><br>

<a href="acceptrequest.php?fuid=<?php echo $g['my_uid'];?>" id="a1">Confrim</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="reject-request.php?fid=<?php echo $g['my_uid'];?>" id="a2">Delete Request</a>
<hr>
<?php }?><div align="center"><b>no more requests</b></div>
</body>
</html>


