<?php 
  session_start();
  include_once "php/config.php";
$sx=$_SESSION['unique_id'];
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
$vs=mysqli_query($conn,"SELECT * FROM users WHERE unique_id=$sx");
$rr=mysqli_fetch_array($vs);
$gh=$rr['verify'];

$cq=mysqli_query($conn,"SELECT COUNT(my_uid) AS sum FROM c_f_r WHERE my_uid='$sx' OR frnd_uid='$sx'");
while($xs=mysqli_fetch_assoc($cq)){

$op=$xs['sum'];
}
$ca=mysqli_query($conn,"SELECT COUNT(frnd_uid) AS sum FROM friend_request WHERE frnd_uid='$sx'");
while($xa=mysqli_fetch_assoc($ca)){

$oc=$xa['sum'];
}
?>
<?php include_once "header.php"; ?>
<body onload="mark()">
  <div class="wrapper">
    <section class="users">
      <header>
        <div class="content">
          <?php 
            $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
            if(mysqli_num_rows($sql) > 0){
              $row = mysqli_fetch_assoc($sql);
            }
          ?>

          <img src="php/images/<?php echo $row['img']; ?>" alt="<?php echo $row['fname']. " " . $row['lname'] ?>">
          <div class="details">
            <span><?php echo $row['fname']. " " . $row['lname'] ?></span>&nbsp;<span style="display:none;" id="vcc"><a href='#'><img style="height:15px;width:15px;" alt="Verified User : <?php echo $row['fname']. " " . $row['lname'] ?>" src="check.png"/></a></span>
            <p><?php echo $row['status']; ?></p>
          </div>
        </div>
     <a href="settings.php"><img src="settings.png" style="height:30px;width:30px;"/></a>
      </header>
      <div class="search">
        <span class="text">Search user to start chat</span>
        <input type="text" placeholder="Enter name to search...">
        <button style="background:none;"><img src="search.png" style="height:40px;width:40px;border-radius:10%;"/></button>
      </div>
<div class="search">
<a href="friend.php"><img style="height:40px;weight:40px;border-radius:0px;" src="add-friend.png" alt="add friend"/></a><br>
<a href="getrequest.php"><span style="float:right;background:#682544;color:white;padding: 03px 03px 03px 03px;object-fit:cover;border-radius: 10px;"><?php echo $oc;?></span> <img style="height:40px;weight:40px;border-radius:0px;margin-right:5px;" src="apple.png" alt="add friend"/></a><a href="myfrnd.php"><span style="float:right;background:#682544;color:white;padding: 03px 03px 03px 03px;object-fit:cover;border-radius: 10px;"><?php echo $op;?></span><img style="height:40px;weight:40px;border-radius:0px;" src="friends.png" alt="add friend"/></a>
<hr>

      </div>
      <div class="users-list">

      </div>
<div align="center"> no more users </div>
    </section>
  </div>

  <script src="javascript/users.js"></script>

<script>
function mark(){
let a= document.querySelector('#vcc');
let b=a.getAttribute('style');
if('<?php echo $gh;?>'=='yes'){
a.setAttribute('style','display:;');
}else{
a.setAttribute('style','display:none;');
}
}
</script>
</body>
</html>
