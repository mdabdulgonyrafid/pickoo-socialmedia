<?php
include('php/config.php');
session_start();
$u=$_SESSION['unique_id'];
$fu=$_GET['fuid'];
$sql=mysqli_query($conn,"SELECT * FROM c_f_r WHERE frnd_uid='$u' AND my_uid='$fu'");
$sql2=mysqli_query($conn,"SELECT * FROM c_f_r WHERE my_uid='$u' AND frnd_uid='$fu'");

if(mysqli_num_rows($sql2)==1){
echo '<script>alert("You have already add him");window.open("friend.php");</script>';
}elseif(mysqli_num_rows($sql)==1){
echo '<script>alert("You have already add him");window.open("friend.php");</script>';
}else{
mysqli_query($conn,"INSERT INTO friend_request VALUES('','$u','$fu')");
header('location:friend.php');
}

?>
