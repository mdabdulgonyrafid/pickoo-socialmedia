<?php
include('php/config.php');
session_start();
if(!isset($_SESSION['unique_id'])){
header('location:login.php');
}
if(isset($_POST['f2'])){
$gn=$_POST['f1'];
$gn2=$_POST['f2'];
$ak=$_SESSION['unique_id'];
$access=mysqli_query($conn,"UPDATE users SET fname='$gn',lname='$gn2' WHERE unique_id='$ak'");
header('location:settings.php');
}
?>