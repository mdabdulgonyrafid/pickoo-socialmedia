<?php
include('php/config.php');
session_start();
$info="";
$info2="";
if(!isset($_SESSION['unique_id'])){
header('location:login.php');
}else{

if(isset($_POST['f2'])){
$gn=$_POST['f1'];
$gn2=$_POST['f2'];
$ak=$_SESSION['unique_id'];
if($gn==NULL){
$info2="<span style='color:red;'>First name could not be empty</span>";
}elseif($gn2==NULL){
$info2="<span style='color:red;'>Last name could not be empty</span>";
}elseif($gn==NULL && $gn2==NULL){
$info2="<span style='color:red;'>Name could not be blank</span>";
}else{
$access=mysqli_query($conn,"UPDATE users SET fname='$gn',lname='$gn2' WHERE unique_id='$ak'");
}
}
if(isset($_POST['op'])){
$old=$_POST['op'];
$new=$_POST['np'];
$con=$_POST['cp'];

$sq=mysqli_query($conn,"SELECT * FROM users WHERE unique_id='$ak'");
$c=mysqli_fetch_array($sq);
$pw=$c['password'];
$has=md5($old);
$hasn=md5($new);
if($old==NULL && $new==NULL && $con==NULL){
$info="<span style='color:red;'>Input field required*</span>";
}elseif($new < 6 && $con < 6){
$info="<span style='color:red;'>Password should be 6 of characters</span>";
}elseif($pw!==$has){
$info="<span style='color:red;'>Old password is wrong</span>";
}elseif($new!==$con){
$info="<span style='color:red;'>New & Confrim pass doesn't match</span>";
}else{
$hh=mysqli_query($conn,"UPDATE users SET password='$hasn' WHERE unique_id='$ak'");
$info="<span style='color:red;'>Password changed successfully</span>";
}
}
}
?>
<?php include_once "header.php"; ?>
<body>
<div class="wrapper"><br>
<a href="users.php"><img src="arrow.png" style="height:30px;width:30px;padding:5px 0px 0px -10px;"/></a>
<section class="users">
      <header>
        <div class="content">
         <?php
$idd=$_SESSION['unique_id'];
$sql=mysqli_query($conn,"SELECT * FROM users WHERE unique_id=$idd");
$fa=mysqli_fetch_array($sql);
$imgs=$fa['img'];
?>

          <div class="details">
         
          </div>
        </div>
    <?php if (isset($_GET['error'])): ?>
		<p><?php echo $_GET['error']; ?></p>
	<?php endif ?>
<div class="profile">
</div>
     <form action="upload.php"
           method="post"
           enctype="multipart/form-data">
<label>
<img src="./php/images/<?php echo $imgs;?>" style="float:left;height: 130px;width:130px;">
           <input type="file"
                  name="my_image" class="custom-file-input" accept="image/*"></label>
<br>
<br>
           <input type="submit" 
                  name="submit"
                  value="Upload" style="border:none;padding: 04px 04px 04px 04px;color:white;border-radius: 6px;background: #214274;margin-left:35px;margin-top:20px;">
    </form>
      </header>

    </section>

      <header>
         <div class="wrapper">
<section class="users">

  <?php
$idd=$_SESSION['unique_id']; $sql=mysqli_query($conn,"SELECT * FROM users WHERE unique_id=$idd"); $fa=mysqli_fetch_array($sql);
$xp=$fa['fname'];
$xpp=$fa['lname'];
?>
<form action="" method="POST">
<h2> Name Change</h2><br>
<?php echo $info2;?><br>
<b>First Name :</b><input type="text" style="font-size:16px;" value="<?php echo $xp;?>" name="f1"/>
<br><br>
<b>Last Name :</b>
<input type="text" style="font-size:16px;" value="<?php echo $xpp;?>" name="f2"/>
<br><br>
<input type="submit" style="border:none;font-size:15px;padding:3px 03px 03px 03px;border-radius:5px;color:white;background: #254243;" value="Save"/>
<br>
<h2>Password Change</h2>
<br>
<form action="" method="POST">
<?php echo $info;?><br>
<b>Old Password :</b><br>
<input type="password" name="op"/><br>
<b>New Password :</b><br>
<input type="password" name="np"/><br>
<b>Confrim Password :</b><br>
<input type="password" name="cp"/><br><br>
<input type="submit" style="border:none;font-size:15px;padding:3px 03px 03px 03px;border-radius:5px;color:white;background: #254243;" value="Change"/><br><br>
</form>
<a href="php/logout.php?logout_id=<?php echo $fa['unique_id']; ?>" style="float:right;border:none;font-size:15px;padding:3px 03px 03px 03px;border-radius:5px;color:white;background: #254243;" class="logout">Logout</a><br>
</form>
    </section>
</div>
          <div class="details">
         
          </div>
        </div>
  
      </header>

    </section>

</div>


</div>
</body>
<script>

</script>
</html>
