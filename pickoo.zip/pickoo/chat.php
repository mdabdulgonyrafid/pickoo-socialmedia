<?php 
  session_start();
  include_once "php/config.php";
  if(!isset($_SESSION['unique_id'])){
    header("location: login.php");
  }
?>
<?php include_once "header.php"; ?>
<body onload="mark()">
  <div class="wrapper">
    <section class="chat-area">
      <header>
        <?php 
          $user_id = mysqli_real_escape_string($conn, $_GET['user_id']);
          $sql = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$user_id}");
$c=mysqli_query($conn,"SELECT * FROM users WHERE unique_id={$user_id}");

if(mysqli_num_rows($c)!==1){
header('location:error/');
}
            $row = mysqli_fetch_assoc($sql);
         
        ?>
        <a href="users.php" style="padding-right:30px" class="back-icon"><img src="arrow.png" style="height:20px;width:20px;float:left;"/></a>
        <img src="php/images/<?php echo $row['img']; ?>" alt="">
        <div class="details">
          <span><?php echo $row['fname']. " " . $row['lname'] ?></span><span style="display:none;padding-right:20px;" id="vcc"><a href='#'><img style="height:15px;width:15px;" alt="verified" src="check.png"/></a></span>
          <p><?php echo $row['status']; ?></p><p id="aaa"></p>
        </div>
      </header>
      <div class="chat-box">

      </div>
      <form action="#" class="typing-area">
        <input type="text" class="incoming_id" name="incoming_id" value="<?php echo $user_id; ?>" hidden>
        <input type="text" name="message" class="input-field" oninput="ttt(this.form)" placeholder="Type a message here..." autocomplete="off">
        <button style="display:hidden;background:none;" ><img src="sent-mail.png"style="height:25px;width:25px;border-radius:0%;" onclick="mm(this.form)"/></button>
      </form>
    </section>
  </div>

  <script src="javascript/chat.js"></script>
<script>
function mm(form){
document.getElementById('aaa').innerHTML="";
}
function ttt(form){
document.getElementById('aaa').innerHTML="Typing....";
}
function mark(){
let a= document.querySelector('#vcc');
let b=a.getAttribute('style');
if('<?php echo $row['verify'];?>'=='yes'){
a.setAttribute('style','display:;');
}else{
a.setAttribute('style','display:none;');
}
}
</script>
</body>
</html>
