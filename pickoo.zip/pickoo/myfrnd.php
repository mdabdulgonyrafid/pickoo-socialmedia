<?php
include('php/config.php');
session_start();
$sb="";
$u=$_SESSION['unique_id'];
if(!isset($u)){
header('login.php');
}else{
$sql=mysqli_query($conn,"SELECT * FROM c_f_r WHERE my_uid='$u'");
$sql2=mysqli_query($conn,"SELECT * FROM c_f_r WHERE frnd_uid='$u'");

}
?>
<html>
<head>
 <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
<style>
a{
text-decoration:none;
color:white;
padding: 04px 04px 04px 04px;
background: #682544;
border-radius: 10px;;
}
</style>
</head>
<body style="font-family:arial;" onload="ass()">
<h2 style="font-family:arial;">Friends</h2>
<?php
while($fff=mysqli_fetch_array($sql)){

?>
<br>
<?php
$cs=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$fff['frnd_uid']}'"));
?>
<div id="zx">
<table cellspacing="0" cellpadding="10" id="zx">
<tr>
<td>
<span><img src="php/images/<?php echo $cs['img'];?>" style="object-fit: cover;border-radius: 50%;height: 45px;width: 45px;margin: 0 15px" alt="<?php echo $cs['fname'];?> <?php echo $cs['lname'];?>"/></span>
</td>
<td>
<span style=""><b><?php echo $cs['fname'];?> <?php echo $cs['lname'];?></b></span>
</td>
<td>
<a href="unfriend.php?fid=<?php echo $cs['unique_id'];?>">Unfriend</a>
</td>
<td>
<a href="report.php">Report</a>
</td>
</tr>
</table>
</div>
<hr>
<?php }?>
<?php
while($ff=mysqli_fetch_array($sql2)){

?>
<br>
<?php
$csx=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$ff['my_uid']}'"));
?>
<div id="xs">
<table style="" cellspacing="0" cellpadding="10" >
<tr>
<td>
<span><img src="php/images/<?php echo $csx['img'];?>" style="object-fit: cover;border-radius: 50%;height: 45px;width: 45px;margin: 0 15px" alt="<?php echo $cs['fname'];?> <?php echo $cs['lname'];?>"/></span>
</td>
<td>
<span style=""><b><?php echo $csx['fname'];?> <?php echo $csx['lname'];?></b></span>
</td>
<td>
<a href="unfriend-opposite.php?fid=<?php echo $csx['unique_id'];?>">Unfriend</a>
</td>
<td>
<a href="report.php">Report</a>
</td>
</tr>
</table>
</div>
<hr>
<?php }?>
<div align="center"><b>no more friends</b></div>
</body>
<script>

</script>
</html>
