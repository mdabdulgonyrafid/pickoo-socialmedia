<?php
include('php/config.php');
session_start();
$ff=$_SESSION['unique_id'];
$sqlx=mysqli_query($conn,"SELECT * FROM users WHERE unique_id!='$ff'");
$sql=mysqli_query($conn,"SELECT * FROM friend_request");
$fff=mysqli_fetch_array($sqlx);
$fx=mysqli_fetch_array($sql);
?>
<html>
<head>
 <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Realtime Chat App | CodingNepal</title>
<style>
#a1{
text-decoration: none;
font-family: arial;
background:#234245;
color:white;
padding: 02px 03px 02px 03px;
border-radius: 5px;
}
#a2{
text-decoration: none;
font-family: arial;
background:grey;
color:white;
padding: 02px 03px 02px 03px;
border-radius: 5px;
}
</style>
</head>
<body onload="mark()" style="font-family:arial">
<h2>Add Friend</h2>
<?php
while($fff=mysqli_fetch_array($sqlx)){

?>
<br>
<?php
$cs=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM users WHERE unique_id='{$fff['unique_id']}'"));
?>
<div style="none">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="php/images/<?php echo $cs['img'];?>" style="object-fit: cover;border-radius: 50%;height: 85px;width: 85px;margin: 0 15px"/><span style="display:none;" id="vcc"><a href='#'><img style="height:15px;width:15px;" alt="verified" src="check.png"/></a></span><br><br>
<span style="font-family:arial;font-weight:bold;margin-left:35px;font-size:20px;"><?php echo $fff['fname'];?>&nbsp;<?php echo $fff['lname'];?></span></div><br><a href="addfrnd.php?fuid=<?php echo $fff['unique_id'];?>" id="a1">Sent Request</a>&nbsp;&nbsp;&nbsp;<a href="deleterequest.php?fuid=<?php echo $fff['unique_id'];?>" id="a2">Delete Request</a><br><hr>

<?php }?>
<div align="center"><b>no more add friends</b></div>
</body>
<script>
<script>
function mark(){
let a= document.querySelector('#vcc');
let b=a.getAttribute('style');
if('<?php echo $cs["verify"]?>'=='yes'){
a.setAttribute('style','display:;');
}else{
a.setAttribute('style','display:none;');
}
}
</script>
</script>
</html>
