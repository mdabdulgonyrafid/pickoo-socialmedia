<?php
include('php/config.php');
session_start();
if(!isset($_SESSION['unique_id'])){
header('location:login.php');
}
$fii=$_GET['msgid'];
$x=$_SESSION['unique_id'];
$sql = mysqli_query($conn,"DELETE FROM messages WHERE msg_id=$fii");
$xxx=$_GET['buddy'];
header("location:./chat.php?user_id=$xxx");
?>
<html>
</html>



